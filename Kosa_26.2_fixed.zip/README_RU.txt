KOSA 26.2 — исправленная сборка

Установка: поместить ZIP в .minecraft/resourcepacks и включить в настройках.

Команда:
 /give @s minecraft:paper[minecraft:custom_model_data={floats:[1.0]}]

В этой версии слот текстуры Blockbench "0" переименован в "kosa",
а все ссылки на него приведены к #kosa. Путь к PNG: assets/minecraft/textures/item/kosa.png.

Совместимость: Minecraft Java 26.2, resource pack format 88.
Для других версий Minecraft могут потребоваться отдельные метаданные и схема моделей.
